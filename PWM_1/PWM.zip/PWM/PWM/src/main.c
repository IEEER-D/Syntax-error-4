
#include <asf.h>
#include <avr/io.h>
#define F_CPU 8000000
#include <util/delay.h>
int main (void)
{
	DDRD = 0xff;
	DDRB |= (1<<PORTB3);
	PORTD = 0xAA;
	OCR0 = 200;
	TCCR0 |= (1<<WGM00) | (1<<WGM00) | (1<<COM01) | (1<<CS02)| (1<<CS00);
	
	
	}
