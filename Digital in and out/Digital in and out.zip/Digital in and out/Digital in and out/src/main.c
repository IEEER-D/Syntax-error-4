#include <asf.h>
#include <avr/io.h>
#define F_CPU 8000000
#include <util/delay.h>
/*
int main (void)
{
	
	DDRB |= (1<<5); // set bit 5 in PORTB as output
	DDRC &= ~(1<<4); // clear bit 4 in PORTC => input
	while(1){
		if(!(PINC & (1<<PINC4))){
		PORTB |= (1<<5);
		_delay_ms(100);
		PORTB &= ~(1<<5);	
		_delay_ms(100);
		}
	}
}
*/

int main (void)
{
	/*
	int i;
	DDRB = 0xff;
	DDRC &= ~(1<<4); // clear bit 4 in PORTC => input
	while(1){
		if((PINC & (1<<PINC4))){
			for (i=0;i<8;i++)
			{
				_delay_ms(100);
				PORTB |= (1<<i);
			}
			for (i=7;i>=0;i--)
			{
				_delay_ms(100);
					PORTB &= ~ (1<<i);
			}
		}
		else 
		{
			PORTB = 0xff;
			_delay_ms(100);
			PORTB =0x00;
			_delay_ms(100);
		}
	}*/
	int i;
	DDRB = 0xff;
	DDRC &= ~(1<<4);
	while(1)
	{
		if(PINC & (1<<PINC4))
		{
			while(PINC & (1<<PINC4));
				for (i=0;i<8;i++)
				{
					_delay_ms(100);
					PORTB |= (1<<i);
				}
				for (i=7;i>=0;i--)
				{
					_delay_ms(100);
					PORTB &= ~ (1<<i);
				}
			
		}else
		PORTB = 0x00;
		}
		}
		

